package fxmlseasweeper;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class PacificController {

    @FXML
    private Button pacificButton;
    @FXML
    private Label label2;

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }
    
    @FXML
    private void pressedKey(KeyEvent e) throws IOException
    {
        //System.out.println("Pressed key");
        
        if(e.getCode().equals(KeyCode.LEFT))
        {
            System.out.println("Pressed left");
        } else if(e.getCode().equals(KeyCode.RIGHT))
        {
            System.out.println("Pressed right");
        }
    }
    
    @FXML
    private void releasedKey(KeyEvent e) throws IOException
    {
        //System.out.println("Released key");
        
        if(e.getCode().equals(KeyCode.LEFT))
        {
            System.out.println("Released left");
        } else if(e.getCode().equals(KeyCode.RIGHT))
        {
            System.out.println("Released right");
        }
    }
}
