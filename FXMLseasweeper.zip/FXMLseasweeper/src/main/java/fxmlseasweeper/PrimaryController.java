package fxmlseasweeper;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

public class PrimaryController implements Initializable{

    @FXML
    private TextArea text1;
    
    @FXML
    private Label label1;
    
    
    @FXML
    public void switchToAtlantic() throws IOException {
        App.setRoot("atlantic");
    }
    
    @FXML
    public void switchToIndian() throws IOException {
        App.setRoot("indian");
    }
    
    @FXML
    public void switchToPacific() throws IOException {
        App.setRoot("pacific");
    }
    
    @FXML
    public void switchToArctic() throws IOException {
        App.setRoot("arctic");
    }
    
    @FXML
    public void switchToSouthern() throws IOException {
        App.setRoot("southern");
    }
    
    @FXML
    public void switchToDumpster() throws IOException {
        App.setRoot("dumpster");
    }

    private String msg = "Hello.." + System.lineSeparator() + "All your base are belong to us";
    //private char mssg = 'x';
    
    //char[] chars = msg.toCharArray();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        text1.setText(msg);
        //label1.setText(msg);
        
        /*label1.setText(chars.charAt(i));
        
        for (int i = 0; i < msg.length(); i++) {
            label1.setText(mssg.charAt(i));
            
            try
            {
                Thread.sleep(300);
            }
            catch (InterruptedException e){
                e.printStackTrace();
            }
        } */
    }
    
    
    

    
    
}
