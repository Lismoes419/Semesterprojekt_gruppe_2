module fxmlseasweeper {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens fxmlseasweeper to javafx.fxml;
    exports fxmlseasweeper;
}