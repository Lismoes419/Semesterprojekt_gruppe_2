package WorldOfZuul;

public enum CommandWord
{
    GO("go"), QUIT("quit"), HELP("help"), UNKNOWN("?"); //Liste af alle vores kommandoer (navnet + hvad vi skal skrive i textfeltet)
    
    private String commandString;
    
    //Constructor
    CommandWord(String commandString)
    {
        this.commandString = commandString; //Sætter dette objekts commandString = vores parameter
    }
    
    //toString metode
    public String toString()
    {
        return commandString; //returnerer vores commandString
    }
}
