package WorldOfZuul;

public class Game 
{
    //Ny parser og nyt rum (currentRoom = nuværende rum)
    private Parser parser;
    private Room currentRoom;
        
    //Game metode
    public Game() 
    {
        createRooms(); //Kalder createRooms() metode
        parser = new Parser(); //Laver ny parser der ikke tager nogen parametre
    }

    //CreateRooms metode
    private void createRooms()
    {
        Room outside, theatre, pub, lab, office; //Laver nye (tomme) rum
      
        //Laver objekterne til rummene, der tager en beskrivelse som parameter
        outside = new Room("outside the main entrance of the university");
        theatre = new Room("in a lecture theatre");
        pub = new Room("in the campus pub");
        lab = new Room("in a computing lab");
        office = new Room("in the computing admin office");
        
        //Laver exits til alle vores rum (tager retning og nyt rum vi kommer til)
        outside.setExit("east", theatre);
        outside.setExit("south", lab);
        outside.setExit("west", pub);

        theatre.setExit("west", outside);

        pub.setExit("east", outside);

        lab.setExit("north", outside);
        lab.setExit("east", office);

        office.setExit("west", lab);

        //Sætter vores nuværende rum til et af de rum vi har oprettet
        currentRoom = outside;
    }

    //Play metode
    public void play() 
    {            
        printWelcome(); //printWelcome metode

                
        boolean finished = false; //ny boolean = false
        while (! finished) { //mens finished = false (Loop indtil finished = true)
            Command command = parser.getCommand(); //Ny kommando = vores text input
            finished = processCommand(command); //Hvis vi skriver quit vil processCommand returnere true og finished vil blive true
        }
        System.out.println("Thank you for playing.  Good bye."); //Når finished = true ryger vi ud af vores loop (IKKE FØR), og vi er færdige med spillet
    }

    //printWelcome metode
    private void printWelcome()
    {
        System.out.println(); //printer ny linje
        System.out.println("Welcome to the World of Zuul!");
        System.out.println("World of Zuul is a new, incredibly boring adventure game.");
        System.out.println("Type '" + CommandWord.HELP + "' if you need help."); //CommandWord.HELP = help (Se CommandWord script)
        System.out.println();
        System.out.println(currentRoom.getLongDescription());
    }

    //Boolean metode (SKAL returnere true eller false)
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false; //ny boolean = false

        CommandWord commandWord = command.getCommandWord(); //ny CommandWord objekt = getCommandWord metode

        if(commandWord == CommandWord.UNKNOWN) { //Hvis vi ikke kender kommandoen
            System.out.println("I don't know what you mean...");
            return false;
        }

        if (commandWord == CommandWord.HELP) { //hvis vi skriver "help"
            printHelp(); //Kald metode
        }
        else if (commandWord == CommandWord.GO) { //hvis vi skriver "go"
            goRoom(command); //Kald metode
        }
        else if (commandWord == CommandWord.QUIT) { //Hvis vi skriver quit
            wantToQuit = quit(command); //boolean = hvad quit(command) returnerer
        }
        return wantToQuit; //returnerer boolean
    }

    //printHelp metode
    private void printHelp() 
    {
        System.out.println("You are lost. You are alone. You wander");
        System.out.println("around at the university.");
        System.out.println(); //ny linje
        System.out.println("Your command words are:");
        parser.showCommands();
    }

    //goRoom metode (tager Command som parameter)
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) { //Hvis vores kommando IKKE har 2 ord
            System.out.println("Go where?");
            return; //stop metode
        }

        String direction = command.getSecondWord(); //ny string der indeholder vores 2. ord (retning)

        Room nextRoom = currentRoom.getExit(direction); //nyt rum = nuværende rum.getExit(retning)

        if (nextRoom == null) { //Check om der er et nextRoom (vi kunne have skrevet forkert)
            System.out.println("There is no door!");
        }
        else { //Ellers ændrer vi vores nuværende rum til det næste rum vi har valgt
            currentRoom = nextRoom;
            System.out.println(currentRoom.getLongDescription()); //printer beskrivelse af det næste rum (som nu er vores nuværende)
        }
    }

    //Quit metode (tager Command som parameter)
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) { //Hvis vi har mere end 1 ord
            System.out.println("Quit what?");
            return false;
        }
        else { //Hvis vi kun har 1 ord
            return true;
        }
    }
}
