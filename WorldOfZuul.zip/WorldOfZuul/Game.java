package WorldOfZuul;

public class Game 
{
    //Ny parser og nyt rum (currentRoom = nuværende rum)
    private Parser parser;
    private Room currentRoom;
    private Player player = new Player();
    
    //Game metode
    public Game()
    {
        ItemDatabase.createList(); //Create items in database
        
        createRooms(); //Kalder createRooms() metode
        //createItems(); //Kalder createItems() metode
        parser = new Parser(); //Laver ny parser der ikke tager nogen parametre
    }
    
    public Room map, dumpster, pacific, atlantic, indian, arctic, southern; //Laver nye (tomme) rum
    
    //CreateRooms metode
    private void createRooms()
    {
        //Laver objekterne til rummene, der tager en beskrivelse som parameter
        map = new Room("in the main area");
        dumpster = new Room("next to a dumpster. Here you can recycle your collected plastic");
        pacific = new Room("in the Pacific Ocean");
        atlantic = new Room("in the Atlantic Ocean");
        indian = new Room("in the Indian Ocean");
        arctic = new Room("in the Arctic Ocean");
        southern = new Room("in the Southern Ocean");
        
        //Laver exits til alle vores rum (tager retning og nyt rum vi kommer til)
        map.setExit("southern", southern);
        map.setExit("pacific", pacific);
        map.setExit("atlantic", atlantic);
        map.setExit("indian", indian);
        map.setExit("arctic", arctic);
        map.setExit("dumpster", dumpster);
        
        dumpster.setExit("map", map);
        dumpster.setExit("pacific", pacific);
        dumpster.setExit("atlantic", atlantic);
        dumpster.setExit("indian", indian);
        dumpster.setExit("southern", southern);
        dumpster.setExit("arctic", arctic);
        
        southern.setExit("map", map);
        southern.setExit("pacific", pacific);
        southern.setExit("atlantic", atlantic);
        southern.setExit("indian", indian);
        southern.setExit("dumpster", dumpster);
        
        pacific.setExit("map", map);
        pacific.setExit("arctic", arctic);
        pacific.setExit("atlantic", atlantic);
        pacific.setExit("indian", indian);
        pacific.setExit("dumpster", dumpster);

        atlantic.setExit("map", map);
        atlantic.setExit("arctic", arctic);
        atlantic.setExit("pacific", pacific);
        atlantic.setExit("indian", indian);
        atlantic.setExit("dumpster", dumpster);

        indian.setExit("map", map);
        indian.setExit("arctic", arctic);
        indian.setExit("atlantic", atlantic);
        indian.setExit("pacific", pacific);
        indian.setExit("dumpster", dumpster);

        arctic.setExit("map", map);
        arctic.setExit("atlantic", atlantic);
        arctic.setExit("pacific", pacific);
        arctic.setExit("dumpster", dumpster);
        

        //Tilføj items
        addItems(pacific, ItemDatabase.pileBottle, 1);
        
        addItems(southern, ItemDatabase.plasticBottle, 5);
        addItems(southern, ItemDatabase.plasticBag, 3);
        
        //Sætter vores nuværende rum til et af de rum vi har oprettet
        currentRoom = map;
    }
    
    //AddItems method
    public void addItems(Room room, Item item, int amt)
    {
        for(int i = 0; i < amt; i++)
        {
            room.setRoomItem(item);
        }
    }
    
    //Play metode
    public void play() 
    {            
        printWelcome(); //printWelcome metode

                
        boolean finished = false; //ny boolean = false
        while (! finished) { //mens finished = false (Loop indtil finished = true)
            Command command = parser.getCommand(); //Ny kommando = vores text input
            finished = processCommand(command); //Hvis vi skriver quit vil processCommand returnere true og finished vil blive true
        }
        System.out.println("Thank you for playing.  Good bye."); //Når finished = true ryger vi ud af vores loop (IKKE FØR), og vi er færdige med spillet
    }

    //printWelcome metode
    private void printWelcome()
    {
        System.out.println(); //printer ny linje
        System.out.println("Welcome to the World of Zuul!");
        System.out.println("World of Zuul is a new, incredibly boring adventure game.");
        System.out.println("Type '" + CommandWord.HELP + "' if you need help."); //CommandWord.HELP = help (Se CommandWord script)
        System.out.println();
        System.out.println(currentRoom.getLongDescription());
    }

    //Boolean metode (SKAL returnere true eller false)
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false; //ny boolean = false

        CommandWord commandWord = command.getCommandWord(); //ny CommandWord objekt = getCommandWord metode

        if(commandWord == CommandWord.UNKNOWN) { //Hvis vi ikke kender kommandoen
            System.out.println("I don't know what you mean...");
            return false;
        }

        if (commandWord == CommandWord.HELP) { //hvis vi skriver "help"
            printHelp(); //Kald metode
        }
        else if (commandWord == CommandWord.GO) { //hvis vi skriver "go"
            goRoom(command); //Kald metode
        }
        else if (commandWord == CommandWord.QUIT) { //Hvis vi skriver quit
            wantToQuit = quit(command); //boolean = hvad quit(command) returnerer
        }
        else if (commandWord == CommandWord.PICKUP) {
            player.addItem(command, currentRoom);
        }
        else if(commandWord == CommandWord.INVENTORY) {
            player.getAllItems();
        }
        else if(commandWord == CommandWord.ROOMITEMS) {
            System.out.println(currentRoom.getRoomItems());
        }
        else if(commandWord == CommandWord.SORT) {
            Dumpster();
        }
        return wantToQuit; //returnerer boolean
    }

    //printHelp metode
    private void printHelp() 
    {
        System.out.println("You are lost. You are alone. You wander");
        System.out.println("around at the university.");
        System.out.println(); //ny linje
        System.out.println("Your command words are:");
        parser.showCommands();
    }

    //goRoom metode (tager Command som parameter)
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) { //Hvis vores kommando IKKE har 2 ord
            System.out.println("Go where?");
            return; //stop metode
        }

        String direction = command.getSecondWord(); //ny string der indeholder vores 2. ord (retning)

        Room nextRoom = currentRoom.getExit(direction); //nyt rum = nuværende rum.getExit(retning)

        if (nextRoom == null) { //Check om der er et nextRoom (vi kunne have skrevet forkert)
            System.out.println("There is no door!");
        }
        else { //Ellers ændrer vi vores nuværende rum til det næste rum vi har valgt
            currentRoom = nextRoom;
            System.out.println(currentRoom.getLongDescription()); //printer beskrivelse af det næste rum (som nu er vores nuværende)
        }
    }
    
    
    //Quit metode (tager Command som parameter)
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) { //Hvis vi har mere end 1 ord
            System.out.println("Quit what?");
            return false;
        }
        else { //Hvis vi kun har 1 ord
            return true;
        }
    }
    
    //dumpster metode
    public  void Dumpster()
    {
        //Check om vi er i det forkerte rum
        if(currentRoom != dumpster)
        {
            System.out.println("You are currently not located by the dumpster"); //Print at vi er i det forkerte rum
            return; //Stop metode
        }
        
        player.addPoints(player.getInventoryValue()); //Tilføj point
        player.emptyInventory(); //Tøm inventory
        
    }
}
