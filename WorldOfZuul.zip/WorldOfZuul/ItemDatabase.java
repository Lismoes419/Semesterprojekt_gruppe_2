package WorldOfZuul;
import java.util.ArrayList;

public class ItemDatabase {
    
    //Single Items
    public static Item plasticBottle = new Item("bottle", 1);
    public static Item plasticBag = new Item("bag", 1);
    public static Item plasticStraw = new Item("straw", 1);
    public static Item plasticJug = new Item("jug", 1);
    public static Item plastic = new Item("plastic", 1);
    public static Item fishingNet = new Item("net", 1);
    public static Item can = new Item("can", 1);
    //Piles
    public static Item pileBottle = new Item("bottles", 10);
    public static Item pileBag = new Item("bags", 10);
    public static Item pileStraw = new Item("straws", 10);
    public static Item pileJug = new Item("jugs", 10);
    public static Item pilePlastic = new Item("plastic", 10);
    public static Item pileCan = new Item("cans", 10);
    
    
    //List
    public static ArrayList<Item> database = new ArrayList<Item>();
    public static void createList()
    {
        database.add(plasticBottle);
        database.add(plasticBag);
        database.add(plasticStraw);
        database.add(plasticJug);
        database.add(plastic);
        database.add(fishingNet);
        database.add(can);
        
        database.add(pileBottle);
    }
    
}
