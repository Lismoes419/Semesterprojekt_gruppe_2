package WorldOfZuul;
import java.util.ArrayList;
import java.lang.reflect.*;

public class Player {
    private int points = 0;
    private ArrayList<Item> inventory = new ArrayList<Item>();
    

    public void addItem(Item item)
    {
        inventory.add(item);
    }
    public void addItem(Command command, Room room)
    {
        if(!command.hasSecondWord()) { //Hvis vores kommando IKKE har 2 ord
            System.out.println("Pick up what?");
            return; //stop metode
        }
        
        String item = command.getSecondWord();
        
        //Check om item er i rummet
        if(!room.getRoomItem(item))
        {
            return; //Stop metode
        }
        
        for(int i = 0; i < ItemDatabase.database.size(); i++)
        {
            if(ItemDatabase.database.get(i).getName().equals(item))
            {
                inventory.add(ItemDatabase.database.get(i)); //Add item to inventory
                room.removeRoomItem(ItemDatabase.database.get(i)); //Remove item from room
                
                System.out.println("You picked up " + ItemDatabase.database.get(i).getName());
                return;
            }
        }
        
        System.err.println("Couldn't find this item");
    }
    
    public void getAllItems()
    {
        if(inventory.size() == 0)
        {
            System.out.println("Your inventory is empty");
            return;
        }
        
        String returnString = "Inventory:";
        for(int i = 0; i < inventory.size(); i++)
        {
            if(i == 0)
            {
                returnString += " " + inventory.get(i).getName();
            } else
            {
                returnString += ", " + inventory.get(i).getName();
            }
        }
        
        System.out.println(returnString);
    }
    
    public void removeItem(Item item, Room room)
    {
        room.setRoomItem(item);
        inventory.remove(item);
    }
    public void emptyInventory()
    {
        for(int i = 0; i < inventory.size(); i++)
        {
            inventory.remove(inventory.get(i));
        }
    }
    
    public int getInventoryValue()
    {
        int value = 0;
        for(int i = 0; i < inventory.size(); i++)
        {
            value += inventory.get(i).getAmount();
        }
        
        return value;
    }
    
    public int getPoints()
    {
        return this.points;
    }
    public void addPoints(int amt)
    {
        this.points += amt;
        System.out.println("You now have " + points + " points");
    }
}
