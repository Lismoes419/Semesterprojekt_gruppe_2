package WorldOfZuul;

import java.util.Set;
import java.util.HashMap;
import java.util.Iterator;


public class Room 
{
    //Opretter beskrivelse og hashmap
    private String description;
    private HashMap<String, Room> exits;

    //Constructor der tager String som argument
    public Room(String description) 
    {
        this.description = description; //Sætter objectets beskrivelse = parameter beskrivelse
        exits = new HashMap<String, Room>(); //Opretter nyt hashmap kaldet "exits"
    }

    //Function der laver nyt exit. Parametre: hvilken retning fra nuværende rum, til hvilket rum
    public void setExit(String direction, Room neighbor) 
    {
        exits.put(direction, neighbor); //Laver nyt exit
    }

    //Returner beskrivelse
    public String getShortDescription()
    {
        return description;
    }

    //Returner lang beskrivelse
    public String getLongDescription()
    {
        return "You are " + description + ".\n" + getExitString(); //".\n" = ny linje
    }

    //Returner alle exits i en string
    private String getExitString()
    {
        String returnString = "Exits:"; //Ny string der skal returneres
        Set<String> keys = exits.keySet(); //Hashmap funktion
        for(String exit : keys) { //Foreach loop
            returnString += " " + exit; //Lægger et mellemrum + navnet på et exit til vores returnString
        }
        return returnString;
    }

    //Returnerer alle exits for det enkelte rum
    public Room getExit(String direction) 
    {
        return exits.get(direction);
    }
}

