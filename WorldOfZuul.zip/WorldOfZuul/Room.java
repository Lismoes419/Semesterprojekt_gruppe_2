package WorldOfZuul;

import java.util.*;
/*
import java.util.Set;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;
*/

public class Room 
{
    //Opretter beskrivelse og hashmap
    private String description;
    private HashMap<String, Room> exits;

    //Lister
    private ArrayList<Item> itemList = new ArrayList<Item>();
    
    //Constructor der tager String som argument
    public Room(String description) 
    {
        this.description = description; //Sætter objectets beskrivelse = parameter beskrivelse
        exits = new HashMap<String, Room>(); //Opretter nyt hashmap kaldet "exits"
    }

    //Function der laver nyt exit. Parametre: hvilken retning fra nuværende rum, til hvilket rum
    public void setExit(String direction, Room neighbor) 
    {
        exits.put(direction, neighbor); //Laver nyt exit
    }

    //Returner beskrivelse
    public String getShortDescription()
    {
        return description;
    }

    //Returner lang beskrivelse
    public String getLongDescription()
    {
        if(itemList.size() == 0)
        {
            return "You are " + description + ".\n" + getExitString();
        } else
        {
            return "You are " + description + ".\n" + getExitString() + System.lineSeparator() + getRoomItems(); //".\n" = ny linje
        }
    }

    //Returner alle exits i en string
    private String getExitString()
    {
        String returnString = "Exits:"; //Ny string der skal returneres
        Set<String> keys = exits.keySet(); //Hashmap funktion
        
        int counter = 0;
        for(String exit : keys) { //Foreach loop
            if(counter == 0)
            {
                returnString += " " + exit; //Lægger et mellemrum + navnet på et exit til vores returnString
                counter++;
            } else
            {
                returnString += ", " + exit; //Lægger et mellemrum + komma + navnet på et exit til vores returnString
            }
        }
        return returnString;
    }

    //Returnerer alle exits for det enkelte rum
    public Room getExit(String direction) 
    {
        return exits.get(direction);
    }
    
    public void setRoomItem(Item item)
    {
        itemList.add(item);
    }
    public void removeRoomItem(Item item)
    {
        for(int i = 0; i < itemList.size(); i++)
        {
            if(itemList.get(i).equals(item))
            {
                itemList.remove(i);
            }
        }
    }
    
    public boolean getRoomItem(String name)
    {
        for(int i = 0; i < itemList.size(); i++)
        {
            if(itemList.get(i).getName().equals(name))
            {
                return true;
            }
        }
        
        System.out.println("There is no such item in this room");
        return false;
    }
    
    public String getRoomItems()
    {
        if(itemList.size() == 0)
        {
            System.out.println("There are no items in this room");
            return null;
        }
        
        String returnString = "Items:";
        for(int i = 0; i < itemList.size(); i++)
        {
            if(i == 0)
            {
                returnString += " " + itemList.get(i).getName();
            } else
            {
                returnString += ", " + itemList.get(i).getName();
            }
        }
        
        return returnString;
    }
}

