package WorldOfZuul;


public class Start {

    //Main metode
    public static void main(String[] args) {
        //TODO code application logic here
        Game game = new Game(); //Nyt game objekt
        game.play(); //Start spil
    }
}
